import 'package:al_quran/nofification/notification.dart';
import 'package:flutter/material.dart';

class Demo extends StatelessWidget {
  const Demo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            ElevatedButton(
              onPressed: () {
                NotificationService.showInstantNotification(
                    "Instant Notification",
                    "This shows an instant notifications");
              },
              child: const Text('Show Notification'),
            ),
            ElevatedButton(
              onPressed: () {
                NotificationService.showProgressNotification(50, 150);
              },
              child: const Text('Show Notification'),
            ),
          ],
        ),
      ),
    );
  }
}
