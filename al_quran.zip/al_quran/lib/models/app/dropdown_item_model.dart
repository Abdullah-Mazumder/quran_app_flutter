class DropdownItem {
  final String value;
  final String labelEn;
  final String labelBn;

  DropdownItem({
    required this.value,
    required this.labelEn,
    required this.labelBn,
  });
}

// class 
